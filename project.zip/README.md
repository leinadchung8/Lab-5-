# jasmineclasstests
using jasmine as in [textbook](https://www.oreilly.com/library/view/object-oriented-javascript/9781785880568/)

This is a starting place for a simple project with tests. I introduced it (start of chapter 12) along with functions chapter 3 as the minimal requirement for tdd. Now that we have covered classes (chapter 8) I added a scaffold for a class under test

To use this:

```
npm install
npm test
```

The tests are in the spec folder, classes_spec.js and functions_spec.js. The units under test are functions.js, and classes.js.

[Edit here](https://diy-pwa.dev/~/gh/rhildred/jasmineclasstests)

